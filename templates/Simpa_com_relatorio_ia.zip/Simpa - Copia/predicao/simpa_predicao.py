"""
SIMPA - Indicador de risco academico (calculo + visao por perfil de acesso).

Formula heuristica da ata (secao 5):
    risco = w1*frequencia_invertida + w2*queda_desempenho
          + w3*desvio_padrao        + w4*inadimplencia

Principios mantidos: indicador continuo (nao binario), proativo, interpretavel
(cada score traz o motivo de cada fator) e pesos como parametro (calibrar com
a secretaria academica).

Bancos (dois arquivos independentes, ver dados_prototipo/):
    dados.db   -> alunos, turmas, notas, frequencia, financeiro (lido aqui, SOMENTE LEITURA)
    acesso.db  -> usuarios e permissoes (lido pelo pacote login/, nunca por este modulo)

Este modulo NAO sabe quem e o usuario: quem decide o escopo e o pacote login/. Ele so recebe
o resultado ja resolvido -- `cursos` (None = todos) ou `codigo_docente` -- e devolve apenas
os alunos daquele escopo. Assim a regra de seguranca fica num ponto so (resultados_visiveis).

Visoes:
    * Global / setor / secretaria / coordenacao: score completo (4 sinais) dos alunos dos
      cursos do escopo.
    * Professor: so os alunos matriculados nas turmas dele, e so o que acontece NAS turmas
      dele (notas e frequencia da disciplina). Inadimplencia e dados de outras disciplinas
      nao entram (privilegio minimo). Os pesos dos 3 sinais academicos sao renormalizados
      para somar 1, mantendo as faixas de classificacao comparaveis.

Uso:
    python predicao/simpa_predicao.py                # relatorio no console (visao global)
    python predicao/simpa_predicao.py --csv r.csv    # exporta CSV (visao global)
    python app.py                                    # front com login (Flask)
"""

import argparse
import csv
import json
import os
import sqlite3
import statistics
import sys
import threading
from collections import defaultdict
from datetime import datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:          # permite rodar este arquivo direto: python predicao/simpa_predicao.py
    sys.path.insert(0, str(RAIZ))

from dados_prototipo.config import DB_DADOS_PATH  # noqa: E402

DB_PATH_PADRAO = DB_DADOS_PATH

# Pesos PLACEHOLDER -- pendentes de validacao com a secretaria (ata, secoes 5 e 12)
PESOS_PADRAO = {
    "w1_frequencia_invertida": 0.30,
    "w2_queda_desempenho": 0.30,
    "w3_desvio_padrao": 0.15,
    "w4_inadimplencia": 0.25,
}
CHAVES_ACADEMICAS = ("w1_frequencia_invertida", "w2_queda_desempenho", "w3_desvio_padrao")
LIMIAR_FREQUENCIA = 0.75

FAIXAS = [
    (0.66, "risco critico", "#C62828"),
    (0.40, "ponto de atencao", "#E65100"),
    (0.0, "regular", "#2E7D32"),
]


def classificar(score):
    for limiar, rotulo, cor in FAIXAS:
        if score >= limiar:
            return rotulo, cor
    return FAIXAS[-1][1], FAIXAS[-1][2]


def pesos_efetivos(pesos, financeiro=True):
    """Pesos de fato usados no score. Sem financeiro (professor), os 3 sinais academicos
    sao renormalizados para somar 1."""
    if financeiro:
        return dict(pesos)
    soma = sum(pesos[k] for k in CHAVES_ACADEMICAS)
    if soma <= 0:
        return {k: 0.0 for k in CHAVES_ACADEMICAS}
    return {k: round(pesos[k] / soma, 4) for k in CHAVES_ACADEMICAS}


# ---------------------------------------------------------------------------
# Carga em lote do dados.db (somente leitura). Poucas queries no total, nada por aluno.
# ---------------------------------------------------------------------------

def _abrir_ro(db_path):
    return sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True)


class Dados:
    """Tudo que o calculo precisa, carregado uma vez do dados.db."""

    def __init__(self, alunos, turmas, matriculas, freq_mat, notas_mat, fin):
        self.alunos = alunos            # [(id_aluno, nome, curso_codigo, curso_nome, periodo)]
        self.turmas = turmas            # id_turma -> {curso, curso_nome, disciplina, codigo_docente, docente}
        self.freq_mat = freq_mat        # id_matricula -> (presencas, total_aulas)
        self.notas_mat = notas_mat      # id_matricula -> [(nota, data)]
        self.fin = fin                  # id_aluno -> [status do boleto]
        self.por_aluno = defaultdict(list)   # id_aluno -> [(id_turma, id_matricula)]
        self.por_turma = defaultdict(list)   # id_turma -> [(id_aluno, id_matricula)]
        for id_mat, id_aluno, id_turma in matriculas:
            self.por_aluno[id_aluno].append((id_turma, id_mat))
            self.por_turma[id_turma].append((id_aluno, id_mat))
        self.alunos_por_id = {a[0]: a for a in alunos}
        self.cursos = sorted({(a[2], a[3]) for a in alunos})   # so cursos que tem aluno


def carregar_tudo(db_path):
    conn = _abrir_ro(db_path)
    try:
        alunos = conn.execute(
            "SELECT a.id_aluno, a.nome, c.codigo, c.nome, a.periodo "
            "FROM aluno a JOIN curso c ON c.id_curso = a.id_curso"
        ).fetchall()
        turmas = {
            i: {"curso": cod, "curso_nome": cnome, "disciplina": disc, "codigo_docente": cd, "docente": dnome}
            for i, cod, cnome, disc, cd, dnome in conn.execute(
                "SELECT t.id_turma, c.codigo, c.nome, t.disciplina, t.codigo_docente, d.nome "
                "FROM turma t JOIN curso c ON c.id_curso = t.id_curso "
                "JOIN docente d ON d.codigo_docente = t.codigo_docente"
            )
        }
        matriculas = conn.execute("SELECT id_matricula, id_aluno, id_turma FROM matricula").fetchall()
        freq_mat = {
            i: (p or 0, t)
            for i, p, t in conn.execute(
                "SELECT id_matricula, SUM(presenca), COUNT(*) FROM frequencia GROUP BY id_matricula")
        }
        notas_mat = defaultdict(list)
        for i, n, d in conn.execute("SELECT id_matricula, nota, data FROM registro_academico"):
            notas_mat[i].append((n, d))
        fin = defaultdict(list)
        for i, s in conn.execute("SELECT id_aluno, status FROM financeiro"):
            fin[i].append(s)
    finally:
        conn.close()
    return Dados(alunos, turmas, matriculas, freq_mat, notas_mat, fin)


def _agregar(dados, pares):
    """pares = [(id_turma, id_matricula)] -> (freq, notas, materias)
    freq = (presencas, total); notas = [(nota, data)]; materias = [(id_turma, media, presencas, total)]"""
    p_tot = t_tot = 0
    notas, materias = [], []
    for id_turma, id_mat in pares:
        p, t = dados.freq_mat.get(id_mat, (0, 0))
        ns = dados.notas_mat.get(id_mat, [])
        p_tot += p
        t_tot += t
        notas.extend(ns)
        media = round(sum(n for n, _ in ns) / len(ns), 1) if ns else None
        materias.append((id_turma, media, p, t))
    return (p_tot, t_tot), notas, materias


# ---------------------------------------------------------------------------
# Os 4 sinais de risco
# ---------------------------------------------------------------------------

def sinal_frequencia_invertida(presencas, total):
    if not total:
        return 0.0, "sem registros de frequencia"
    taxa = presencas / total
    motivo = f"frequencia de {taxa:.0%} ({presencas}/{total} aulas)"
    if taxa < LIMIAR_FREQUENCIA:
        motivo += f" -- abaixo do limiar institucional de {LIMIAR_FREQUENCIA:.0%}"
    return 1 - taxa, motivo


def sinal_queda_desempenho(notas):
    """Tendencia (regressao linear) da media das notas por data de avaliacao.

    Agrupar por data e necessario: com as notas de todas as disciplinas em uma
    serie unica, o slope ficava dividido pelo numero de disciplinas e a queda
    era subestimada.
    """
    por_data = defaultdict(list)
    for nota, data in notas:
        por_data[data].append(nota)
    valores = [sum(v) / len(v) for _, v in sorted(por_data.items())]
    if len(valores) < 2:
        return 0.0, "historico de notas insuficiente para tendencia"

    n = len(valores)
    media_x, media_y = (n - 1) / 2, sum(valores) / n
    num = sum((i - media_x) * (v - media_y) for i, v in enumerate(valores))
    den = sum((i - media_x) ** 2 for i in range(n))
    slope = num / den if den else 0.0

    if slope >= 0:
        return 0.0, f"desempenho estavel ou em alta (tendencia {slope:+.2f} pontos/avaliacao)"
    return min(abs(slope), 1.0), f"queda de desempenho (tendencia {slope:+.2f} pontos/avaliacao)"


def sinal_desvio_padrao(notas):
    if len(notas) < 2:
        return 0.0, "historico insuficiente para medir instabilidade"
    desvio = statistics.stdev(n for n, _ in notas)
    return min(desvio / 5.0, 1.0), f"desvio-padrao das notas de {desvio:.2f}"


def sinal_inadimplencia(status_boletos):
    if not status_boletos:
        return 0.0, "sem registros financeiros"
    pendentes = status_boletos.count("pendente")
    return pendentes / len(status_boletos), f"{pendentes}/{len(status_boletos)} boletos pendentes"


# ---------------------------------------------------------------------------
# Hipotese de causa provavel: combina os 4 sinais em um diagnostico legivel.
# So depende dos valores brutos dos sinais (nao dos pesos), entao e o mesmo
# texto qualquer que seja a calibracao de w1..w4 escolhida depois.
# Limiares abaixo tambem sao placeholder, a calibrar com a secretaria.
# ---------------------------------------------------------------------------
FREQ_LIMIAR, QUEDA_LIMIAR, DESVIO_LIMIAR, INADIMP_LIMIAR = 0.25, 0.15, 0.30, 0.30


def diagnosticar(fatores, financeiro=True):
    """financeiro=False (visao do professor): o sinal de inadimplencia nao existe, entao
    o texto nao pode afirmar 'sem pendencia financeira' -- nao sabemos."""
    nem_fin = " nem pendencia financeira" if financeiro else ""
    ou_fin = " ou financeiro" if financeiro else ""
    v = {f["fator"]: f["valor"] for f in fatores}
    freq_alta = v["frequencia_invertida"] > FREQ_LIMIAR
    queda_alta = v["queda_desempenho"] > QUEDA_LIMIAR
    instavel = v["desvio_padrao"] > DESVIO_LIMIAR
    inadimplente = v.get("inadimplencia", 0) > INADIMP_LIMIAR

    if freq_alta and inadimplente and queda_alta:
        return ("Frequencia baixa, queda de desempenho e pendencia financeira ao mesmo tempo -- "
                "quadro mais grave, sugere abandono em curso, nao um fator isolado.")
    if freq_alta and inadimplente:
        return ("Padrao associado a evasao por dificuldade financeira combinada com afastamento das aulas "
                "-- comum quando o aluno reduz a presenca ao mesmo tempo em que atrasa os pagamentos.")
    if freq_alta and queda_alta:
        return ("Baixa frequencia acompanhada de queda de desempenho -- sugere desengajamento "
                "progressivo, nao apenas uma fase isolada.")
    if freq_alta and instavel:
        return ("Frequencia baixa com notas instaveis -- pode ser efeito das faltas nas avaliacoes; "
                "vale checar se as faltas coincidem com dias de prova.")
    if freq_alta:
        return (f"Frequencia baixa isolada, sem queda de notas{nem_fin} -- pode indicar "
                "dificuldade de conciliar horarios (trabalho, deslocamento) mais do que desinteresse academico.")
    if inadimplente and queda_alta:
        return ("Pendencia financeira e queda de desempenho juntas -- a dificuldade financeira pode "
                "estar afetando a dedicacao aos estudos.")
    if inadimplente:
        return ("Pendencia financeira predominante, com frequencia e notas dentro do esperado -- risco "
                "financeiro isolado, nao necessariamente ligado ao desempenho.")
    if queda_alta and instavel:
        return (f"Queda e instabilidade nas notas sem problema de frequencia{ou_fin} -- sugere "
                "dificuldade com o conteudo de disciplinas especificas.")
    if queda_alta:
        return ("Queda de desempenho isolada, sem outro sinal relevante -- indicio de dificuldade "
                "recente; vale acompanhar se persiste.")
    if instavel:
        return "Notas instaveis sem outro sinal relevante -- pode ser variacao normal entre avaliacoes diferentes."
    if any(val > 0 for val in v.values()):
        return "Combinacao leve de fatores, nenhum isoladamente forte -- indicador de atencao preventiva."
    return "Sem sinais de risco relevantes nos dados disponiveis."


def calcular_risco_aluno(aluno, freq, notas, fin, pesos, financeiro=True):
    """`pesos` ja deve ser o dicionario efetivo (ver pesos_efetivos).
    financeiro=False -> o fator de inadimplencia nem e calculado."""
    id_aluno, nome, curso, curso_nome, periodo = aluno
    valores = [
        ("frequencia_invertida", "w1_frequencia_invertida", sinal_frequencia_invertida(*freq)),
        ("queda_desempenho", "w2_queda_desempenho", sinal_queda_desempenho(notas)),
        ("desvio_padrao", "w3_desvio_padrao", sinal_desvio_padrao(notas)),
    ]
    if financeiro:
        valores.append(("inadimplencia", "w4_inadimplencia", sinal_inadimplencia(fin)))
    fatores = [
        {"fator": nome_f, "peso": pesos[chave], "valor": round(v, 3), "motivo": motivo}
        for nome_f, chave, (v, motivo) in valores
    ]
    score = round(min(sum(f["peso"] * f["valor"] for f in fatores), 1.0), 3)
    rotulo, cor = classificar(score)
    principal = max(fatores, key=lambda f: f["peso"] * f["valor"])
    notas_valores = [n for n, _ in notas]
    return {
        "id_aluno": id_aluno, "nome": nome, "curso": curso, "curso_nome": curso_nome, "periodo": periodo,
        "score": score, "classificacao": rotulo, "cor": cor,
        "motivo_principal": principal["motivo"], "fatores": fatores,
        "diagnostico": diagnosticar(fatores, financeiro),
        "nota_media": round(sum(notas_valores) / len(notas_valores), 2) if notas_valores else None,
    }


# ---------------------------------------------------------------------------
# Cache + visoes por escopo
# ---------------------------------------------------------------------------
_lock = threading.Lock()
_cache = {"db": None, "dados": None, "res": {}, "doc": {}}


def obter_dados(db_path):
    with _lock:
        if _cache["dados"] is None or _cache["db"] != str(db_path):
            _cache.update(db=str(db_path), dados=carregar_tudo(db_path), res={}, doc={})
        return _cache["dados"]


def _chave_pesos(pesos):
    return json.dumps(pesos, sort_keys=True)


def obter_resultados(db_path, pesos):
    """Visao GLOBAL (todos os alunos, 4 sinais). Uso interno + admin/reitor geral."""
    dados = obter_dados(db_path)
    chave = _chave_pesos(pesos)
    with _lock:
        res = _cache["res"].get(chave)
    if res is None:
        res = []
        for aluno in dados.alunos:
            freq, notas, materias = _agregar(dados, dados.por_aluno.get(aluno[0], []))
            r = calcular_risco_aluno(aluno, freq, notas, dados.fin.get(aluno[0], []), pesos)
            r["materias"] = materias
            res.append(r)
        res.sort(key=lambda r: r["score"], reverse=True)
        with _lock:
            if len(_cache["res"]) > 8:
                _cache["res"].clear()
            _cache["res"][chave] = res
    return res


def obter_resultados_docente(db_path, codigo_docente, pesos):
    """Visao do PROFESSOR: so alunos das turmas dele, so dados dessas turmas, sem financeiro."""
    dados = obter_dados(db_path)
    chave = (codigo_docente, _chave_pesos(pesos))
    with _lock:
        res = _cache["doc"].get(chave)
    if res is None:
        efetivos = pesos_efetivos(pesos, financeiro=False)
        minhas = [i for i, t in dados.turmas.items() if t["codigo_docente"] == codigo_docente]
        por_aluno = defaultdict(list)
        for id_turma in minhas:
            for id_aluno, id_mat in dados.por_turma.get(id_turma, []):
                por_aluno[id_aluno].append((id_turma, id_mat))
        res = []
        for id_aluno, pares in por_aluno.items():
            freq, notas, materias = _agregar(dados, pares)
            r = calcular_risco_aluno(dados.alunos_por_id[id_aluno], freq, notas, [], efetivos, financeiro=False)
            r["materias"] = materias
            res.append(r)
        res.sort(key=lambda r: r["score"], reverse=True)
        with _lock:
            if len(_cache["doc"]) > 200:
                _cache["doc"].clear()
            _cache["doc"][chave] = res
    return res


def resultados_visiveis(db_path, pesos, cursos=None, codigo_docente=None):
    """PONTO UNICO de controle de escopo. Devolve (resultados, financeiro).

    codigo_docente != None -> visao do professor (cursos e ignorado).
    cursos is None         -> visao global.
    cursos = {...}         -> so alunos desses cursos (conjunto vazio = ninguem: falha fechada).
    """
    if codigo_docente is not None:
        return obter_resultados_docente(db_path, codigo_docente, pesos), False
    todos = obter_resultados(db_path, pesos)
    if cursos is None:
        return todos, True
    return [r for r in todos if r["curso"] in cursos], True


def filtros_visiveis(db_path, cursos=None, codigo_docente=None):
    """Cursos e materias (turmas) que o usuario pode ver, para montar os filtros do front."""
    dados = obter_dados(db_path)
    if codigo_docente is not None:
        turmas = {i: t for i, t in dados.turmas.items() if t["codigo_docente"] == codigo_docente}
        codigos = {t["curso"] for t in turmas.values()}
        lista_cursos = [(c, n) for c, n in dados.cursos if c in codigos]
    else:
        lista_cursos = [(c, n) for c, n in dados.cursos if cursos is None or c in cursos]
        permitidos = {c for c, _ in lista_cursos}
        turmas = {i: t for i, t in dados.turmas.items() if t["curso"] in permitidos}
    materias = sorted(
        ({"id": i, "curso": t["curso"], "disciplina": t["disciplina"], "docente": t["docente"]}
         for i, t in turmas.items()),
        key=lambda m: (m["curso"], m["disciplina"]))
    return [{"codigo": c, "nome": n} for c, n in lista_cursos], materias


def serializar(r, turmas):
    """Resultado -> dict JSON do front (materias com nome da disciplina/docente)."""
    return {
        "nome": r["nome"], "curso": r["curso"], "curso_nome": r["curso_nome"], "periodo": r["periodo"],
        "score": r["score"], "classificacao": r["classificacao"], "cor": r["cor"],
        "motivo_principal": r["motivo_principal"], "fatores": r["fatores"],
        "diagnostico": r["diagnostico"], "nota_media": r["nota_media"],
        "materias": [
            {"id_turma": i, "disciplina": turmas[i]["disciplina"], "docente": turmas[i]["docente"],
             "media": m, "presencas": p, "total": t}
            for i, m, p, t in r["materias"]
        ],
    }


def calcular_kpis(resultados, financeiro=True):
    """Metricas de contexto pro painel, calculadas sobre a lista JA FILTRADA (escopo + filtros).

    Nao ha registro de trancamento/abandono no schema (so risco continuo), entao a taxa de
    "risco critico" e usada como aproximacao de evasao.
    Sem financeiro (professor), taxa_inadimplencia vem None e o front esconde o card.
    """
    n = len(resultados)
    if not n:
        return {"media_geral": None, "frequencia_media": None, "taxa_inadimplencia": None,
                "taxa_evasao_proxy": None, "total_alunos": 0}
    notas = [r["nota_media"] for r in resultados if r.get("nota_media") is not None]
    freqs, inadimp, criticos = [], [], 0
    for r in resultados:
        v = {f["fator"]: f["valor"] for f in r["fatores"]}
        freqs.append(1 - v["frequencia_invertida"])
        if financeiro:
            inadimp.append(v["inadimplencia"])
        if r["classificacao"] == "risco critico":
            criticos += 1
    return {
        "media_geral": round(sum(notas) / len(notas), 2) if notas else None,
        "frequencia_media": round(sum(freqs) / n, 3),
        "taxa_inadimplencia": round(sum(inadimp) / n, 3) if financeiro else None,
        "taxa_evasao_proxy": round(criticos / n, 3),
        "total_alunos": n,
    }


def agrupar(db_path, resultados, modo="materia", limite=100):
    """Agrega os resultados (ja no escopo) por materia ou por professor.
    Devolve (total_de_grupos, linhas[:limite]) ordenadas pela taxa de risco critico (proxy de evasao)."""
    turmas = obter_dados(db_path).turmas
    ag = {}
    for r in resultados:
        em_risco = r["classificacao"] != "regular"
        critico = r["classificacao"] == "risco critico"
        for id_turma, media, p, t in r["materias"]:
            chave = turmas[id_turma]["codigo_docente"] if modo == "professor" else id_turma
            a = ag.get(chave)
            if a is None:
                a = ag[chave] = {"n": 0, "soma": 0.0, "nmedia": 0, "p": 0, "t": 0,
                                 "risco": 0, "critico": 0, "turmas": set()}
            a["n"] += 1
            if media is not None:
                a["soma"] += media
                a["nmedia"] += 1
            a["p"] += p
            a["t"] += t
            a["risco"] += em_risco
            a["critico"] += critico
            a["turmas"].add(id_turma)
    linhas = []
    for chave, a in ag.items():
        n = a["n"]
        linha = {
            "alunos": n,
            "media": round(a["soma"] / a["nmedia"], 1) if a["nmedia"] else None,
            "frequencia": round(a["p"] / a["t"], 3) if a["t"] else None,
            "em_risco": a["risco"], "criticos": a["critico"],
            "pct_risco": a["risco"] / n, "pct_critico": a["critico"] / n,
        }
        if modo == "professor":
            t0 = turmas[next(iter(a["turmas"]))]
            linha.update(codigo_docente=chave, docente=t0["docente"], turmas=len(a["turmas"]))
        else:
            t0 = turmas[chave]
            linha.update(id_turma=chave, disciplina=t0["disciplina"], curso=t0["curso"],
                         curso_nome=t0["curso_nome"], docente=t0["docente"])
        linhas.append(linha)
    linhas.sort(key=lambda x: (-x["pct_critico"], -x["pct_risco"], -x["alunos"]))
    return len(linhas), linhas[:limite]


# ---------------------------------------------------------------------------
# Saidas: console, CSV
# ---------------------------------------------------------------------------

def imprimir_relatorio(resultados, top=None):
    if top:
        resultados = resultados[:top]
    print(f"\nSIMPA - Indicador de Risco Academico ({datetime.now():%d/%m/%Y %H:%M})")
    print("=" * 78)
    for r in resultados:
        print(f"[{r['classificacao'].upper():15s}] {r['nome']:30s} score={r['score']:.3f}")
        print(f"    motivo principal: {r['motivo_principal']}")
        print(f"    hipotese de causa: {r['diagnostico']}")
    print("=" * 78)
    criticos = sum(1 for r in resultados if r["classificacao"] == "risco critico")
    atencao = sum(1 for r in resultados if r["classificacao"] == "ponto de atencao")
    print(f"Total: {len(resultados)} alunos | {criticos} em risco critico | {atencao} em ponto de atencao\n")


def _celula(valor):
    """Evita injecao de formula quando o CSV e aberto no Excel (=, +, -, @ no inicio)."""
    if isinstance(valor, str) and valor[:1] in ("=", "+", "-", "@"):
        return "'" + valor
    return valor


def escrever_csv(resultados, f):
    w = csv.writer(f)
    w.writerow(["id_aluno", "nome", "curso", "periodo", "score", "classificacao", "motivo_principal", "hipotese_causa"])
    for r in resultados:
        w.writerow([_celula(x) for x in (r["id_aluno"], r["nome"], r["curso"], r["periodo"], r["score"],
                                          r["classificacao"], r["motivo_principal"], r["diagnostico"])])


def exportar_csv(resultados, caminho):
    with open(caminho, "w", newline="", encoding="utf-8") as f:
        escrever_csv(resultados, f)
    print(f"CSV exportado em: {caminho}")


def ler_pesos(raw):
    pesos = dict(PESOS_PADRAO)
    try:
        for k, v in json.loads(raw or "{}").items():
            if k in pesos and float(v) >= 0:
                pesos[k] = float(v)
    except (ValueError, TypeError, AttributeError):
        pass
    return pesos


def main():
    parser = argparse.ArgumentParser(description="SIMPA - indicador de risco academico (visao global, via console)")
    parser.add_argument("--db", default=DB_PATH_PADRAO, help="Caminho do dados.db")
    parser.add_argument("--pesos", default=None, help='Pesos em JSON, ex: \'{"w1_frequencia_invertida":0.4}\'')
    parser.add_argument("--top", type=int, default=None, help="Mostrar so os N de maior risco")
    parser.add_argument("--csv", default=None, help="Exportar relatorio em CSV")
    args = parser.parse_args()

    if not os.path.exists(args.db):
        raise SystemExit(f"Banco nao encontrado em '{args.db}'. Rode antes: python -m dados_prototipo.gerar_simpa_db")

    pesos = ler_pesos(args.pesos)
    if abs(sum(pesos.values()) - 1.0) > 1e-6:
        print(f"Aviso: soma dos pesos = {sum(pesos.values()):.3f} (recomendado somar 1.0)")
    resultados = obter_resultados(args.db, pesos)
    imprimir_relatorio(resultados, top=args.top)
    if args.csv:
        exportar_csv(resultados, args.csv)


if __name__ == "__main__":
    main()
